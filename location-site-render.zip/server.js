const express = require("express");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static("public"));

let lastLocation = null;

app.post("/location", (req, res) => {
    const { latitude, longitude } = req.body;

    if (typeof latitude !== "number" || typeof longitude !== "number") {
        return res.status(400).json({ message: "Неверные координаты" });
    }

    lastLocation = {
        latitude,
        longitude,
        time: new Date().toISOString()
    };

    const mapUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;

    console.log("Получено местоположение:", latitude, longitude);
    console.log("Карта:", mapUrl);

    res.json({ success: true, mapUrl });
});

app.get("/location", (req, res) => {
    if (!lastLocation) {
        return res.json({ message: "Местоположение пока не получено" });
    }

    res.json({
        ...lastLocation,
        mapUrl: `https://www.google.com/maps?q=${lastLocation.latitude},${lastLocation.longitude}`
    });
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server started on port ${PORT}`);
});
