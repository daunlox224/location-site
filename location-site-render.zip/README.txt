RENDER

1. Создай GitHub repository.
2. Загрузи server.js, package.json и папку public.
3. На Render выбери New -> Web Service.
4. Подключи этот GitHub repository.
5. Build Command: npm install
6. Start Command: npm start
7. Выбери Free и создай сервис.

Render автоматически выдаст HTTPS-ссылку вида:
https://название.onrender.com

Геолокация работает только после явного разрешения пользователя браузером.
